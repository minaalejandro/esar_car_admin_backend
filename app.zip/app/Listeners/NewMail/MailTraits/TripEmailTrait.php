<?php

namespace App\Listeners\NewMail\MailTraits;


trait TripEmailTrait
{

    public function valuesForTripEmails()
    {

    }
}